var date = new Date();
var offset = date.getTimezoneOffset();
//alert(offset);

$(".timeOffset").val(offset);
